/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Hp
 */
public class Method1 {
    
    public static Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bnlivein_lict?verifyServerCertificate=false&useSSL=true", "root", "130102065");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
        return conn;
    }
    
    
    
    
    
      public static int save(Ticket c) {
        int status = 0;
        try {
            Connection conn = Method.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                    "insert into ticket_g049605(name,source,dist,time,date) values(?,?,?,?,?)");

            ps.setString(1, c.getName());
            ps.setString(2, c.getSource());
            ps.setString(3, c.getDist());
            ps.setString(4, c.getTime());
            ps.setString(5, c.getDate());
         
          

            status = ps.executeUpdate();

            conn.close();
        } catch (Exception e) {
        }
        return status;
    }
     public static List<Ticket> getAllData() {
        List<Ticket> list = new ArrayList<Ticket>();

        try {
            Connection conn = Method.getConnection();
            PreparedStatement ps = conn.prepareStatement("select * from ticket_g049605");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Ticket c = new Ticket();
                c.setId(rs.getInt(1));
                c.setName(rs.getString(2));
                c.setSource(rs.getString(3));
                c.setDist(rs.getString(4));
                c.setTime(rs.getString(5));
                c.setDate(rs.getString(6));
          
                list.add(c);
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    
}
     
      public static Ticket getIdData(int id) {
        Ticket c = new Ticket();

        try {
            Connection conn = Method1.getConnection();
            PreparedStatement ps = conn.prepareStatement("select * from ticket_g049605 where id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                c.setId(rs.getInt(1));
                c.setName(rs.getString(2));
                c.setSource(rs.getString(3));
                c.setDist(rs.getString(4));
                c.setTime(rs.getString(5));
                c.setDate(rs.getString(6));
              
            }
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return c;
    }
      
      public static int update(Ticket c) {
        int status = 0;
        try {
            Connection conn = Method1.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                    "UPDATE ticket_g049605 SET name=?, source=?, dist=?, time=?, date=? WHERE id=?");

            ps.setString(1, c.getName());
            ps.setString(2, c.getSource());
            ps.setString(3, c.getDist());
            ps.setString(4, c.getTime());
            ps.setString(5, c.getDate());
            ps.setInt(6, c.getId());

            status = ps.executeUpdate();

            conn.close();
        } catch (Exception e) {
        }
        return status;
     
}
       public static int delete(int id) {
        int status = 0;
        try {
            Connection conn = Method1.getConnection();
            PreparedStatement ps = conn.prepareStatement("delete from ticket_g049605 where id=?");
            ps.setInt(1, id);

            status = ps.executeUpdate();

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
}
}
