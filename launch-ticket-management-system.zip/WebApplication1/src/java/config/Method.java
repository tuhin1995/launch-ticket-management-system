/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Hp
 */
public class Method {
    
         public static Connection getConnection() {
        Connection conn = null;
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bnlivein_lict?verifyServerCertificate=false&useSSL=true", "root", "130102065");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
        return conn;
    }

    public static int save(Entity d) {
        int status = 0;
        try {
            Connection conn = Method.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                    "insert into user_g049605 (name, gender, dofb, address, mobile, email, pass) values (?,?,?,?,?,?,?)");

            ps.setString(1, d.getName());
            ps.setString(2, d.getGender());
            ps.setString(3, d.getDofb());
            ps.setString(4, d.getAdress());
            ps.setInt(5, d.getMobile());
            ps.setString(6, d.getEmail());
            ps.setString(7, d.getPass());
          

            status = ps.executeUpdate();

            conn.close();
        } catch (Exception e) {
        }
        return status;
    }

    public static int update(Entity d) {
        int status = 0;
        try {
            Connection conn = Method.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                    "update empdetails set name=?, gender=?, dofb=?, address=?, mobile=?, email=?, pass=?, nid=?, design=?, local=?, salary=?, others=? where id =?");

            ps.setString(1, d.getName());
            ps.setString(2, d.getGender());
            ps.setString(3, d.getDofb());
            ps.setString(4, d.getAdress());
            ps.setInt(5, d.getMobile());
            ps.setString(6, d.getEmail());
            ps.setString(7, d.getPass());
          
            ps.setInt(8, d.getId());

            status = ps.executeUpdate();

            conn.close();
        } catch (Exception e) {
        }
        return status;
    }

    public static int delete(int id) {
        int status = 0;
        try {
            Connection conn = Method.getConnection();
            PreparedStatement ps = conn.prepareStatement("delete from empdetails where id=?");
            ps.setInt(1, id);

            status = ps.executeUpdate();

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }

    public static Entity getIdData(int id) {
        Entity d = new Entity();

        try {
            Connection conn = Method.getConnection();
            PreparedStatement ps = conn.prepareStatement("select * from empdetails where id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                d.setId(rs.getInt(1));
                d.setName(rs.getString(2));
                d.setGender(rs.getString(3));
                d.setDofb(rs.getString(4));
                d.setAdress(rs.getString(5));
                d.setMobile(rs.getInt(6));
                d.setEmail(rs.getString(7));
                d.setPass(rs.getString(8));
               
            }
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return d;
    }

    public static List<Entity> getAllData() {
        List<Entity> list = new ArrayList<Entity>();

        try {
            Connection conn = Method.getConnection();
            PreparedStatement ps = conn.prepareStatement("select * from ticket_g049605");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Entity d = new Entity();
                d.setId(rs.getInt(1));
                d.setName(rs.getString(2));
                d.setGender(rs.getString(3));
                d.setDofb(rs.getString(4));
                d.setAdress(rs.getString(5));
                d.setMobile(rs.getInt(6));
                d.setEmail(rs.getString(7));
                d.setPass(rs.getString(8));
          
                list.add(d);
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    
   
}
   


    

