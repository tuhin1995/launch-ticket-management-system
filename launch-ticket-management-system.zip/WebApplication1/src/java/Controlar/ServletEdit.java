/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlar;

import config.Method1;
import config.Ticket;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Hp
 */
public class ServletEdit extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();  
        
        int id=Integer.parseInt(request.getParameter("id"));  
          
        Ticket c = Method1.getIdData(id);  
        out.println("<h2 align=center>"+c.getName()+" Details !</h2>");
        out.print("<form action='servletupdate' method='get'>");  
        out.print("<table align=center>");  
        out.print("<tr><td></td><td><input type='hidden' name='id' value='"+c.getId()+"'/></td></tr>");  
        out.print("<tr><td>Name:</td><td><input type='text' name='name' value='"+c.getName()+"'/></td></tr>");  
        out.print("<tr><td>Source:</td><td><input type='text' name='source' value='"+c.getSource()+"'/> </td></tr>");  
        out.print("<tr><td>District:</td><td><input type='text' name='dist' value='"+c.getDist()+"'/></td></tr>"); 
        out.print("<tr><td>Time:</td><td><input type='text' name='time' value='"+c.getTime()+"'/></td></tr>");  
        out.print("<tr><td>Date:</td><td><input type='int' name='date' value='"+c.getDate()+"'/> </td></tr>");  
       
        out.print("<tr><td colspan='2' ><input type='submit' value=' UPDATE '/></td></tr>");  
        out.print("</table>");  
        out.print("</form>");  
          
        out.close();
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
