/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

/**
 *
 * @author Hp
 */
public class Entity {
    
     int id;
    String name;
    String gender;
    String dofb;
    String adress;
    int mobile;
    String email;
    String pass;

    public Entity() {
        
        
    }

    public Entity(String name, String gender, String dofb, String adress, int mobile, String email) {
        this.name = name;
        this.gender = gender;
        this.dofb = dofb;
        this.adress = adress;
        this.mobile = mobile;
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDofb() {
        return dofb;
    }

    public void setDofb(String dofb) {
        this.dofb = dofb;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public int getMobile() {
        return mobile;
    }

    public void setMobile(int mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

  
    
    
    
}
